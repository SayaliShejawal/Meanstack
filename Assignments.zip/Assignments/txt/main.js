const display = () => {
    console.log("hi");
}

const display1 = () => {
    console.log("hi55");
}

display();
display1();