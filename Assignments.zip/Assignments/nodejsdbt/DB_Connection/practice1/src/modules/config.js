const dbCon = {
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'nodejsdbt'
};

module.exports = { dbCon };