/*
class Calculator {

    add(n1, n2) {
        return n1 + n2;
        ;
    }

    subtract(n1, n2) {
        return n1 - n2;
    };
};

let obj = new Calculator();
let obj1 = new Calculator();
let op = obj.add(10, 5);
let op1 = obj.subtract(10, 5);

console.log(op);
console.log(op1);
*/

/*
class Calculator {

    add(n1, n2) {
        return n1 + n2;
    }


    subtract(n1, n2) {
        return n1 - n2;
    }

    static main() {

        let obj = new Calculator();

        let op = obj.add(10, 5);
        let op1 = obj.subtract(10, 5);

        console.log(op);
        console.log(op1);
    }
}

Calculator.main();
*/


















